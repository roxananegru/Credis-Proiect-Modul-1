Nume: Negru Roxana Alexandra
Tema: Magazin online de tablouri
Descriere: Magazin online pentru tablouri unde clientii pot accesa usor cele mai noi produse si pot vedea ofertele (prima pagina), pot cauta produsul dorit utilizand bara de search si pot comanda un produs.
De asemenea contine o pagina cu informatii despre echipa si un scurt videoclip de prezentare. Magazinul aduce toate paginile reale din procesul de cumparare si anume Selectare produse - Previzualizare - Completare date client - Metoda de plata - Thank you page.
Curs urmat: Web Developer
Surse de inspiratie: 
https://preview.themeforest.net/item/aivo-multipurpose-portfolio-html-website-template/full_screen_preview/21587861
https://colorlib.com/preview/#karma
https://www.dhgate.com/product/muya-abstract-painting-canvas-vertical-oil/410211561.html
Biblioteci externe: Bootstrap, jQuery, Popper (tooltip bootstrap), FontAwesome